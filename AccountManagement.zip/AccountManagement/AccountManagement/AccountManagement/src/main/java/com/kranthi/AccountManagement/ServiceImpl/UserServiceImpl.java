package com.kranthi.AccountManagement.ServiceImpl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.kranthi.AccountManagement.Exceptions.ResourceNotFoundException;
import com.kranthi.AccountManagement.Model.Users;
import com.kranthi.AccountManagement.Repo.UserRepo;
import com.kranthi.AccountManagement.Service.UserService;

@Service
public class UserServiceImpl implements UserService{
	
	private UserRepo repo;
	
	public UserServiceImpl(UserRepo repo) {
		this.repo = repo;
	}

	@Override
	public Users createUsers(Users user) {
		if (repo.findByEmail(user.getEmail()).isPresent()) {
	        throw new RuntimeException("Email already exists: " + user.getEmail());
	    }
		if (repo.findByAccountNumber(user.getAccountNumber()).isPresent()) {
	        throw new RuntimeException("Account number already exists: " + user.getAccountNumber());
	    }
	    if (repo.findByPhoneNumber(user.getPhoneNumber()).isPresent()) {
	        throw new RuntimeException("Phone number already exists: " + user.getPhoneNumber());
	    }
		return repo.save(user);
	}

	@Override
	public List<Users> getAllUsers() {
		return repo.findAll();
	}

	@Override
	public Users getUserById(Long id) {
		return repo.findById(id).orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
	}

	@Override
	public Users updateUser(Long id, Users user) {
		Users existing = getUserById(id);
        existing.setName(user.getName());
        existing.setEmail(user.getEmail());
        existing.setPassword(user.getPassword());      
        existing.setAccountNumber(user.getAccountNumber());
        existing.setPhoneNumber(user.getPhoneNumber());
        existing.setGender(user.getGender());
        existing.setAddress(user.getAddress());
        return repo.save(existing);
	}

	@Override
	public void deleteUser(Long id) {
		Users user = getUserById(id);
        repo.delete(user);
		
	}

}
