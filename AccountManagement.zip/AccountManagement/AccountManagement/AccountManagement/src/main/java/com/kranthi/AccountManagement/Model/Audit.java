package com.kranthi.AccountManagement.Model;

import java.security.Timestamp;

import org.springframework.data.annotation.CreatedDate;

import jakarta.persistence.Column;


public abstract class Audit {
	
	@Column(name = "account_status", nullable = false)
    private boolean accountStatus = true; 
	
	@CreatedDate
	private Timestamp accountCreatedDate;
	
	

}
